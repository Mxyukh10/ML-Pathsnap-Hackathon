import json
import streamlit as st

def show_json(data):
    st.json(data, expanded=True)
