import json
import folium
import streamlit as st
from streamlit_folium import st_folium

def _find_coordinate_list(obj):
    """Find common coordinate arrays in JSON responses without assuming one API schema."""
    if isinstance(obj, dict):
        for key in ("coordinates", "gps_points", "points", "trajectory", "matched_coordinates", "route_coordinates"):
            value = obj.get(key)
            if isinstance(value, list) and value:
                coords = _normalise(value)
                if coords:
                    return coords, key
        for value in obj.values():
            found = _find_coordinate_list(value)
            if found:
                return found
    elif isinstance(obj, list):
        coords = _normalise(obj)
        if coords:
            return coords, "list"
        for value in obj:
            found = _find_coordinate_list(value)
            if found:
                return found
    return None

def _normalise(values):
    out = []
    for item in values:
        if isinstance(item, dict):
            lat = item.get("latitude", item.get("lat"))
            lon = item.get("longitude", item.get("lon", item.get("lng")))
            if lat is not None and lon is not None:
                out.append((float(lat), float(lon)))
        elif isinstance(item, (list, tuple)) and len(item) >= 2:
            # Assumes [latitude, longitude]. Change if backend returns [longitude, latitude].
            out.append((float(item[0]), float(item[1])))
    return out if len(out) >= 1 else None

def render_map(response):
    found = _find_coordinate_list(response)
    if not found:
        st.info("No recognised coordinate list found in the API response. The raw response is still available above. Expected keys include coordinates, points, trajectory, or matched_coordinates.")
        return
    coords, source_key = found
    center = coords[0]
    m = folium.Map(location=center, zoom_start=14, control_scale=True)
    folium.PolyLine(coords, color="#2563eb", weight=5, opacity=0.85, tooltip=source_key).add_to(m)
    folium.Marker(coords[0], tooltip="Start", icon=folium.Icon(color="green")).add_to(m)
    if len(coords) > 1:
        folium.Marker(coords[-1], tooltip="End", icon=folium.Icon(color="red")).add_to(m)
    st_folium(m, use_container_width=True, height=480)
