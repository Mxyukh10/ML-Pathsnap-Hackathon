import requests

def _url(base_url: str, endpoint: str) -> str:
    return base_url.rstrip("/") + "/" + endpoint.lstrip("/")

def check_api(base_url: str):
    # FastAPI commonly exposes /openapi.json. This checks reachability without assuming a custom health route.
    try:
        response = requests.get(_url(base_url, "/openapi.json"), timeout=8)
        if response.ok:
            return True, f"Backend reachable: {base_url}"
        return False, f"Backend responded with HTTP {response.status_code}"
    except requests.RequestException as exc:
        return False, f"Cannot reach backend: {exc}"

def call_api(base_url, endpoint, method="POST", body=None, params=None, timeout=60):
    url = _url(base_url, endpoint)
    response = requests.request(
        method=method.upper(),
        url=url,
        json=body if method.upper() == "POST" else None,
        params=params if method.upper() == "GET" else None,
        timeout=timeout,
    )
    try:
        data = response.json()
    except ValueError:
        data = {"raw_response": response.text}
    return response.status_code, data
