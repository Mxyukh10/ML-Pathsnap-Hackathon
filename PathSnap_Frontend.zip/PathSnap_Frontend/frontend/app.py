import json
import os
from pathlib import Path

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from api_client import call_api, check_api
from map_visualization import render_map
from components import show_json

load_dotenv()
st.set_page_config(page_title="PathSnap | GPS Map Matching", page_icon="🗺️", layout="wide")

DEFAULT_API = os.getenv("API_BASE_URL", "http://127.0.0.1:8000")
st.title("PathSnap")
st.caption("GPS trajectory map-matching interface")

with st.sidebar:
    st.header("Backend connection")
    api_base = st.text_input("FastAPI base URL", value=DEFAULT_API,
                             help="For another laptop, use its LAN IP, e.g. http://192.168.1.10:8000")
    if st.button("Check API", use_container_width=True):
        ok, detail = check_api(api_base)
        (st.success if ok else st.error)(detail)
    st.divider()
    st.subheader("Request settings")
    method = st.selectbox("HTTP method", ["POST", "GET"])
    endpoint = st.text_input("Endpoint path", value="/predict",
                             help="Change this to the exact route shown in your FastAPI /docs.")
    timeout = st.number_input("Request timeout (seconds)", min_value=5, max_value=300, value=60)

left, right = st.columns([1, 1])
with left:
    st.subheader("1. Provide trip input")
    uploaded = st.file_uploader("Upload a JSON or CSV trip file", type=["json", "csv"])
    sample = {
        "trip_id": "demo-trip",
        "observations": [
            {"latitude": 12.9716, "longitude": 77.5946, "timestamp": "2026-11-18T09:00:00"},
            {"latitude": 12.9720, "longitude": 77.5950, "timestamp": "2026-11-18T09:00:05"}
        ]
    }
    if uploaded:
        raw = uploaded.getvalue()
        try:
            if uploaded.name.lower().endswith(".json"):
                payload_obj = json.loads(raw.decode("utf-8"))
            else:
                df = pd.read_csv(uploaded)
                st.write("CSV preview")
                st.dataframe(df.head(10), use_container_width=True)
                payload_obj = {"observations": df.to_dict(orient="records")}
            payload_text = json.dumps(payload_obj, indent=2)
        except Exception as exc:
            st.error(f"Could not read file: {exc}")
            payload_text = json.dumps(sample, indent=2)
    else:
        payload_text = json.dumps(sample, indent=2)

    request_text = st.text_area("Request JSON body", value=payload_text, height=260)
    send = st.button("Send trip to backend", type="primary", use_container_width=True)

with right:
    st.subheader("2. Prediction response")
    st.caption("The request schema and endpoint must match your backend's FastAPI documentation.")
    if send:
        try:
            body = json.loads(request_text) if method == "POST" else None
            params = body if method == "GET" and isinstance(body, dict) else None
            status, result = call_api(api_base, endpoint, method, body, params, int(timeout))
            st.session_state["last_response"] = result
            st.session_state["last_status"] = status
            if status < 400:
                st.success(f"API returned HTTP {status}")
            else:
                st.error(f"API returned HTTP {status}")
        except json.JSONDecodeError as exc:
            st.error(f"Invalid JSON: {exc}")
        except Exception as exc:
            st.error(f"Request failed: {exc}")

    if "last_response" in st.session_state:
        st.write(f"HTTP status: {st.session_state.get('last_status')}")
        show_json(st.session_state["last_response"])

st.divider()
st.subheader("3. Route map")
response = st.session_state.get("last_response")
if response is not None:
    render_map(response)
else:
    st.info("After a successful prediction, supported coordinate arrays in the response will be plotted here.")

st.caption("This is a configurable integration shell. Set the endpoint and request JSON to match your backend's /docs contract.")
