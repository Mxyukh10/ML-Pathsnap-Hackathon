# PathSnap Frontend

A Streamlit UI shell for connecting to the PathSnap FastAPI backend.

## Requirements
- Windows 10/11
- Python 3.10 or newer
- Backend reachable over the same LAN/Wi-Fi

## Run on Windows
1. Extract this ZIP.
2. Open the extracted `PathSnap_Frontend` folder in VS Code.
3. Double-click `run.bat`, or run these commands in PowerShell:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
streamlit run frontend/app.py
```

4. Open http://localhost:8501.

## Connect to FastAPI on another laptop
1. On the backend laptop, start FastAPI listening on all interfaces:

```powershell
uvicorn main:app --host 0.0.0.0 --port 8000
```

Replace `main:app` with the actual module and application variable in your backend.
2. On the backend laptop, run `ipconfig` and find its Wi-Fi/Ethernet IPv4 address.
3. On the frontend laptop, copy `.env.example` to `.env` and set:

```env
API_BASE_URL=http://BACKEND_LAN_IP:8000
```

Replace `BACKEND_LAN_IP` with the actual address, for example `192.168.1.10`.
4. Ensure both laptops are on the same network.
5. Allow Python/Uvicorn through Windows Firewall on the backend laptop, preferably on Private networks only.
6. In the UI sidebar, click **Check API**.

## Important: match your actual API contract
This project does not assume the PathSnap endpoint or request schema. Open the backend's `http://BACKEND_LAN_IP:8000/docs` and check:
- exact HTTP method (GET/POST)
- exact endpoint path
- required JSON request fields
- response fields

Enter the endpoint path in the sidebar and edit the Request JSON body to match the schema. The initial `/predict` and example JSON are placeholders only.

The map renderer recognises common response coordinate keys: `coordinates`, `gps_points`, `points`, `trajectory`, `matched_coordinates`, and `route_coordinates`. If your API uses another key or returns longitude-first coordinate pairs, update `frontend/map_visualization.py`.

## GitHub
From the project root:

```bash
git init
git add .
git commit -m "Initial PathSnap frontend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/PathSnap.git
git push -u origin main
```

Do not commit `.env`, API keys, private data, model weights, or student/evaluator test data.

## Troubleshooting
- **Connection refused:** check Uvicorn is running with `--host 0.0.0.0`, port 8000, and correct IP.
- **Timeout:** check both devices are on the same network and Windows Firewall allows inbound TCP 8000.
- **404:** endpoint path is wrong; check `/docs`.
- **422:** request JSON does not match the FastAPI request schema; copy the schema from `/docs`.
- **CORS:** this UI uses server-side Python HTTP requests, so browser CORS configuration is generally not required.
